#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
import re
import shutil

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "android" / "app" / "src" / "main" / "res"
MANIFEST = ROOT / "android" / "app" / "src" / "main" / "AndroidManifest.xml"
JAVA_DIR = ROOT / "android" / "app" / "src" / "main" / "java" / "com" / "aurex" / "controlgastos"
MAIN = JAVA_DIR / "MainActivity.java"
ICON = ROOT / "assets" / "aurex-icon.png"

# ------------------------------------------------
# 1. ICONO REAL AUREX
# ------------------------------------------------
img = Image.open(ICON).convert("RGBA")
for folder in RES.glob("mipmap-*"):
    if folder.is_dir():
        for f in folder.glob("ic_launcher*"):
            if f.is_file() or f.is_symlink():
                f.unlink()
            elif f.is_dir():
                shutil.rmtree(f)

anydpi = RES / "mipmap-anydpi-v26"
if anydpi.exists():
    for f in anydpi.glob("ic_launcher*.xml"):
        f.unlink()

sizes = {"mdpi":48,"hdpi":72,"xhdpi":96,"xxhdpi":144,"xxxhdpi":192}
for density, px in sizes.items():
    dest = RES / ("mipmap-" + density)
    dest.mkdir(parents=True, exist_ok=True)
    out = img.resize((px,px), Image.Resampling.LANCZOS)
    out.save(dest / "ic_launcher.png")
    out.save(dest / "ic_launcher_round.png")

# ------------------------------------------------
# 2. PERMISO PARA ANDROID 9 O ANTERIOR
# ------------------------------------------------
manifest = MANIFEST.read_text(encoding="utf-8")
permission = '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />'
if permission not in manifest:
    manifest = manifest.replace("<application", permission + "\n    <application", 1)
    MANIFEST.write_text(manifest, encoding="utf-8")

# ------------------------------------------------
# 3. BRIDGE NATIVO: GUARDA PNG EN DESCARGAS/AUREX
# ------------------------------------------------
JAVA_DIR.mkdir(parents=True, exist_ok=True)

java = r"""package com.aurex.controlgastos;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.net.Uri;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import com.getcapacitor.BridgeActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends BridgeActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Expone solo esta interfaz al HTML local empaquetado dentro de Aurex.
        getBridge().getWebView().addJavascriptInterface(
            new AurexAndroidBridge(this),
            "AurexAndroid"
        );
    }

    public static class AurexAndroidBridge {
        private final Context context;

        AurexAndroidBridge(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public boolean isNativeApp() {
            return true;
        }

        @JavascriptInterface
        public String saveImage(String dataUrl, String filename) {
            try {
                if (filename == null || filename.trim().isEmpty()) {
                    filename = "Aurex_Comprobante.png";
                }

                String payload = dataUrl;
                int comma = payload.indexOf(',');
                if (comma >= 0) {
                    payload = payload.substring(comma + 1);
                }

                byte[] bytes = Base64.decode(payload, Base64.DEFAULT);

                // Android 10+: MediaStore / scoped storage.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentResolver resolver = context.getContentResolver();
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                    values.put(MediaStore.Downloads.MIME_TYPE, "image/png");
                    values.put(
                        MediaStore.Downloads.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/Aurex"
                    );
                    values.put(MediaStore.Downloads.IS_PENDING, 1);

                    Uri uri = resolver.insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                        values
                    );

                    if (uri == null) {
                        throw new Exception("Android no pudo crear el archivo");
                    }

                    try (OutputStream stream = resolver.openOutputStream(uri)) {
                        if (stream == null) {
                            throw new Exception("No se pudo abrir el archivo");
                        }
                        stream.write(bytes);
                        stream.flush();
                    } catch (Exception ex) {
                        resolver.delete(uri, null, null);
                        throw ex;
                    }

                    values.clear();
                    values.put(MediaStore.Downloads.IS_PENDING, 0);
                    resolver.update(uri, values, null, null);

                    return "OK|Descargas/Aurex/" + filename;
                }

                // Android 9 o anterior.
                File downloads = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS
                );
                File aurexDir = new File(downloads, "Aurex");

                if (!aurexDir.exists() && !aurexDir.mkdirs()) {
                    throw new Exception("No se pudo crear Descargas/Aurex");
                }

                File file = new File(aurexDir, filename);
                try (FileOutputStream stream = new FileOutputStream(file)) {
                    stream.write(bytes);
                    stream.flush();
                }

                return "OK|Descargas/Aurex/" + filename;

            } catch (Exception error) {
                String message = error.getMessage();
                if (message == null) message = error.getClass().getSimpleName();
                return "ERROR|" + message;
            }
        }
    }
}
"""
MAIN.write_text(java, encoding="utf-8")

print("Aurex Android native bridge instalado.")
print("Guardado: Descargas/Aurex/")
print("MainActivity:", MAIN)
