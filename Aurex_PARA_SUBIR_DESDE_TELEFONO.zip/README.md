# Aurex


## Corrección Back Android
El botón Atrás nativo de Android está conectado directamente a la pila interna de Aurex.


## Back Android v2
Corrección: `aurexHandlePhysicalBack` ahora se expone en `window`, permitiendo que
el botón Atrás nativo recorra la pila de Aurex antes de cerrar la aplicación.
