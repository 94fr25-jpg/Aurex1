# Aurex


## Corrección Back Android
El botón Atrás nativo de Android está conectado directamente a la pila interna de Aurex.


## Back Android v2
Corrección: `aurexHandlePhysicalBack` ahora se expone en `window`, permitiendo que
el botón Atrás nativo recorra la pila de Aurex antes de cerrar la aplicación.


## Back Android — implementación oficial
Esta versión usa `@capacitor/app` y su evento `backButton`.

Secuencia esperada:
- Comprobante → vista anterior
- Vista anterior → la anterior
- Resumen/Ajustes → pantalla previa
- Pagos/inicio → siguiente Atrás cierra Aurex

Se eliminó el `onBackPressed()` personalizado de MainActivity para evitar doble manejo del botón Atrás.
