# Aurex


## Corrección Back Android
El botón Atrás nativo de Android está conectado directamente a la pila interna de Aurex.
